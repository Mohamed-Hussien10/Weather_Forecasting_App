List iconState = [
  {
    "clearlight": "assets/images/sun.png",
    "clearnight": "assets/images/moon-and-stars (1).png",
    "clouds": "assets/images/cloud.png",
    "rain": "assets/images/rainy-day.png",
    "wind": "assets/images/storm.png",
    "snow": "assets/images/snow.png",
    "fog": "assets/images/fog.png",
    "mist": "assets/images/fog.png",
    "unknownWeather": "assets/images/unknownWeather.png"
  }
];
